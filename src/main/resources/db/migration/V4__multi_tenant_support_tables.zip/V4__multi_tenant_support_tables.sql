-- ============================================
-- V4__multi_tenant_support_tables.sql
-- Migration compatible avec les 3 modes : SHARED, DEDICATED, CABINET
-- ============================================

-- ============================================
-- TABLE: cabinets (pour MODE CABINET uniquement)
-- ============================================
CREATE TABLE IF NOT EXISTS cabinets (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    tax_id VARCHAR(50) UNIQUE,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    postal_code VARCHAR(10),
    city VARCHAR(100),
    country VARCHAR(2) NOT NULL DEFAULT 'CM',
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    
    -- LIMITES DU PLAN (pour MODE CABINET)
    max_companies INTEGER NOT NULL DEFAULT 10,
    max_users INTEGER NOT NULL DEFAULT 5,
    plan VARCHAR(50) DEFAULT 'STARTER',
    
    -- AUDIT
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100),
    updated_at TIMESTAMP,
    updated_by VARCHAR(100),
    version BIGINT DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_cabinets_active ON cabinets(is_active);
CREATE INDEX IF NOT EXISTS idx_cabinets_plan ON cabinets(plan);

COMMENT ON TABLE cabinets IS 'Cabinets comptables - Utilisé uniquement en MODE CABINET';

-- ============================================
-- MODIFICATION: companies (support 3 modes)
-- ============================================

-- Ajouter cabinet_id (NULLABLE pour MODE SHARED/DEDICATED)
ALTER TABLE companies ADD COLUMN IF NOT EXISTS cabinet_id BIGINT REFERENCES cabinets(id) ON DELETE CASCADE;

-- Ajouter des champs spécifiques MODE CABINET
ALTER TABLE companies ADD COLUMN IF NOT EXISTS dossier_type VARCHAR(20) DEFAULT 'CLIENT';
ALTER TABLE companies ADD COLUMN IF NOT EXISTS client_reference VARCHAR(50);
ALTER TABLE companies ADD COLUMN IF NOT EXISTS is_demo BOOLEAN DEFAULT FALSE;

CREATE INDEX IF NOT EXISTS idx_companies_cabinet ON companies(cabinet_id);
CREATE INDEX IF NOT EXISTS idx_companies_type ON companies(dossier_type);

COMMENT ON COLUMN companies.cabinet_id IS 'ID du cabinet (NULL en MODE SHARED/DEDICATED, NOT NULL en MODE CABINET)';
COMMENT ON COLUMN companies.dossier_type IS 'Type de dossier : CLIENT, DEMO, ARCHIVED (MODE CABINET uniquement)';
COMMENT ON COLUMN companies.client_reference IS 'Référence client du cabinet (ex: CLI-0001)';

-- ============================================
-- MODIFICATION: users (support 3 modes)
-- ============================================

-- ⚠️ IMPORTANT : On GARDE company_id pour MODE SHARED/DEDICATED
-- On AJOUTE cabinet_id pour MODE CABINET
-- Selon le mode, seulement 1 des 2 sera utilisé

-- Ajouter cabinet_id (NULLABLE)
ALTER TABLE users ADD COLUMN IF NOT EXISTS cabinet_id BIGINT REFERENCES cabinets(id) ON DELETE CASCADE;

-- Ajouter user_type
ALTER TABLE users ADD COLUMN IF NOT EXISTS user_type VARCHAR(20) DEFAULT 'STANDARD';

CREATE INDEX IF NOT EXISTS idx_users_cabinet ON users(cabinet_id);
CREATE INDEX IF NOT EXISTS idx_users_type ON users(user_type);

COMMENT ON COLUMN users.cabinet_id IS 'ID du cabinet (NULL en MODE SHARED/DEDICATED, NOT NULL en MODE CABINET)';
COMMENT ON COLUMN users.user_type IS 'Type utilisateur : ADMIN_CABINET, COLLABORATOR, CLIENT, STANDARD';

-- ⚠️ CONTRAINTE : En MODE CABINET, l'email doit être unique au niveau du cabinet, pas globalement
-- En MODE SHARED, l'email est unique globalement
-- On ne peut pas créer cette contrainte conditionnelle en SQL pur, 
-- donc on la gère dans le code Java

-- ============================================
-- TABLE: user_company_access (pour MODE CABINET)
-- ============================================
CREATE TABLE IF NOT EXISTS user_company_access (
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    company_id BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    access_level VARCHAR(20) DEFAULT 'READ_WRITE', -- READ_ONLY, READ_WRITE, ADMIN
    granted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    granted_by VARCHAR(100),
    PRIMARY KEY (user_id, company_id)
);

CREATE INDEX IF NOT EXISTS idx_user_company_access_user ON user_company_access(user_id);
CREATE INDEX IF NOT EXISTS idx_user_company_access_company ON user_company_access(company_id);

COMMENT ON TABLE user_company_access IS 'Accès des utilisateurs aux dossiers - MODE CABINET uniquement';

-- ============================================
-- TABLE: cabinet_invoices (pour MODE CABINET)
-- ============================================
CREATE TABLE IF NOT EXISTS cabinet_invoices (
    id BIGSERIAL PRIMARY KEY,
    cabinet_id BIGINT NOT NULL REFERENCES cabinets(id) ON DELETE CASCADE,
    invoice_number VARCHAR(50) NOT NULL UNIQUE,
    invoice_date DATE NOT NULL,
    due_date DATE NOT NULL,
    
    -- MONTANTS
    amount_ht DECIMAL(15,2) NOT NULL,
    vat_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    amount_ttc DECIMAL(15,2) NOT NULL,
    
    -- STATUT
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, PAID, OVERDUE, CANCELLED
    paid_at TIMESTAMP,
    payment_method VARCHAR(50),
    
    -- DESCRIPTION
    period_start DATE,
    period_end DATE,
    description TEXT,
    notes TEXT,
    
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100),
    updated_at TIMESTAMP,
    updated_by VARCHAR(100)
);

CREATE INDEX IF NOT EXISTS idx_cabinet_invoices_cabinet ON cabinet_invoices(cabinet_id);
CREATE INDEX IF NOT EXISTS idx_cabinet_invoices_status ON cabinet_invoices(status);
CREATE INDEX IF NOT EXISTS idx_cabinet_invoices_date ON cabinet_invoices(invoice_date);

COMMENT ON TABLE cabinet_invoices IS 'Facturation des cabinets - MODE CABINET uniquement';

-- ============================================
-- TABLE: time_tracking (pour MODE CABINET)
-- ============================================
CREATE TABLE IF NOT EXISTS time_tracking (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    company_id BIGINT NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    
    task_date DATE NOT NULL,
    duration_minutes INTEGER NOT NULL,
    task_description TEXT,
    task_type VARCHAR(50), -- SAISIE, REVISION, DECLARATION, CONSEIL, AUTRE
    
    is_billable BOOLEAN NOT NULL DEFAULT TRUE,
    hourly_rate DECIMAL(10,2),
    
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100)
);

CREATE INDEX IF NOT EXISTS idx_time_tracking_user ON time_tracking(user_id);
CREATE INDEX IF NOT EXISTS idx_time_tracking_company ON time_tracking(company_id);
CREATE INDEX IF NOT EXISTS idx_time_tracking_date ON time_tracking(task_date);
CREATE INDEX IF NOT EXISTS idx_time_tracking_billable ON time_tracking(is_billable);

COMMENT ON TABLE time_tracking IS 'Suivi temps passé par dossier - MODE CABINET uniquement';

-- ============================================
-- TABLE: tenant_metadata (pour tous les modes)
-- ============================================
CREATE TABLE IF NOT EXISTS tenant_metadata (
    id BIGSERIAL PRIMARY KEY,
    tenant_mode VARCHAR(20) NOT NULL, -- SHARED, DEDICATED, CABINET
    tenant_id VARCHAR(100) NOT NULL UNIQUE,
    
    -- Pour MODE DEDICATED
    company_id BIGINT REFERENCES companies(id),
    
    -- Pour MODE CABINET
    cabinet_id BIGINT REFERENCES cabinets(id),
    
    -- Métadonnées
    display_name VARCHAR(200),
    subdomain VARCHAR(100),
    custom_domain VARCHAR(200),
    
    -- Configuration
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    settings JSONB,
    
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_tenant_metadata_mode ON tenant_metadata(tenant_mode);
CREATE INDEX IF NOT EXISTS idx_tenant_metadata_active ON tenant_metadata(is_active);

COMMENT ON TABLE tenant_metadata IS 'Métadonnées tenant - Utilisé pour les 3 modes';

-- ============================================
-- VUES UTILITAIRES
-- ============================================

-- Vue: Statistiques par cabinet (MODE CABINET)
CREATE OR REPLACE VIEW v_cabinet_stats AS
SELECT 
    cab.id AS cabinet_id,
    cab.name AS cabinet_name,
    cab.plan,
    COUNT(DISTINCT c.id) AS total_companies,
    COUNT(DISTINCT u.id) AS total_users,
    cab.max_companies,
    cab.max_users,
    (COUNT(DISTINCT c.id)::FLOAT / NULLIF(cab.max_companies, 0) * 100) AS usage_companies_pct,
    (COUNT(DISTINCT u.id)::FLOAT / NULLIF(cab.max_users, 0) * 100) AS usage_users_pct,
    cab.is_active
FROM cabinets cab
LEFT JOIN companies c ON c.cabinet_id = cab.id AND c.is_active = TRUE
LEFT JOIN users u ON u.cabinet_id = cab.id AND u.is_active = TRUE
GROUP BY cab.id;

COMMENT ON VIEW v_cabinet_stats IS 'Statistiques utilisation cabinets - MODE CABINET uniquement';

-- Vue: Temps passé par dossier (MODE CABINET)
CREATE OR REPLACE VIEW v_time_by_company AS
SELECT 
    c.id AS company_id,
    c.name AS company_name,
    c.client_reference,
    c.cabinet_id,
    COUNT(tt.id) AS total_tasks,
    SUM(tt.duration_minutes) AS total_minutes,
    ROUND(SUM(tt.duration_minutes) / 60.0, 2) AS total_hours,
    ROUND(SUM(CASE WHEN tt.is_billable THEN tt.duration_minutes ELSE 0 END) / 60.0, 2) AS billable_hours,
    ROUND(AVG(tt.hourly_rate), 2) AS avg_hourly_rate,
    MAX(tt.task_date) AS last_activity_date
FROM companies c
LEFT JOIN time_tracking tt ON tt.company_id = c.id
WHERE c.cabinet_id IS NOT NULL
GROUP BY c.id;

COMMENT ON VIEW v_time_by_company IS 'Temps passé par dossier - MODE CABINET uniquement';

-- Vue: Utilisateurs avec leurs accès (MODE CABINET)
CREATE OR REPLACE VIEW v_user_company_access AS
SELECT 
    u.id AS user_id,
    u.email,
    u.first_name,
    u.last_name,
    u.cabinet_id,
    cab.name AS cabinet_name,
    c.id AS company_id,
    c.name AS company_name,
    c.client_reference,
    uca.access_level,
    uca.granted_at
FROM users u
LEFT JOIN cabinets cab ON cab.id = u.cabinet_id
LEFT JOIN user_company_access uca ON uca.user_id = u.id
LEFT JOIN companies c ON c.id = uca.company_id
WHERE u.cabinet_id IS NOT NULL;

COMMENT ON VIEW v_user_company_access IS 'Accès utilisateurs aux dossiers - MODE CABINET uniquement';

-- ============================================
-- NOUVEAUX RÔLES POUR MODE CABINET
-- ============================================
INSERT INTO roles (name, description) VALUES
    ('ROLE_ADMIN_CABINET', 'Administrateur du cabinet - Accès total à tous les dossiers')
ON CONFLICT (name) DO NOTHING;

INSERT INTO roles (name, description) VALUES
    ('ROLE_COLLABORATOR', 'Collaborateur - Accès aux dossiers assignés uniquement')
ON CONFLICT (name) DO NOTHING;

INSERT INTO roles (name, description) VALUES
    ('ROLE_CLIENT', 'Client - Consultation uniquement de son propre dossier')
ON CONFLICT (name) DO NOTHING;

-- Permissions pour Admin Cabinet (accès total)
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
    (SELECT id FROM roles WHERE name = 'ROLE_ADMIN_CABINET'),
    id
FROM permissions
WHERE NOT EXISTS (
    SELECT 1 FROM role_permissions 
    WHERE role_id = (SELECT id FROM roles WHERE name = 'ROLE_ADMIN_CABINET')
    AND permission_id = permissions.id
);

-- ============================================
-- FONCTION: Détecter le mode tenant actuel
-- ============================================
CREATE OR REPLACE FUNCTION get_current_tenant_mode()
RETURNS VARCHAR AS $$
DECLARE
    cabinet_count INTEGER;
    tenant_count INTEGER;
BEGIN
    -- Compter les cabinets
    SELECT COUNT(*) INTO cabinet_count FROM cabinets WHERE is_active = TRUE;
    
    -- Compter les tenants metadata
    SELECT COUNT(*) INTO tenant_count FROM tenant_metadata WHERE is_active = TRUE;
    
    -- Déterminer le mode
    IF cabinet_count > 0 THEN
        RETURN 'CABINET';
    ELSIF tenant_count > 0 THEN
        SELECT tenant_mode INTO STRICT FROM tenant_metadata WHERE is_active = TRUE LIMIT 1;
        RETURN tenant_mode;
    ELSE
        RETURN 'SHARED';
    END IF;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION get_current_tenant_mode IS 'Détecte automatiquement le mode de déploiement de la BDD';

-- ============================================
-- DONNÉES D'EXEMPLE (pour tests uniquement)
-- ============================================

-- Insérer un tenant metadata pour le mode SHARED (si aucune table n'existe encore)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM tenant_metadata) THEN
        INSERT INTO tenant_metadata (tenant_mode, tenant_id, display_name, is_active)
        VALUES ('SHARED', 'shared-instance', 'Instance Partagée PREDYKT', TRUE);
    END IF;
END $$;

-- ============================================
-- INDEXES DE PERFORMANCE
-- ============================================

-- Index composite pour requêtes fréquentes en MODE CABINET
CREATE INDEX IF NOT EXISTS idx_companies_cabinet_active 
    ON companies(cabinet_id, is_active) WHERE cabinet_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_users_cabinet_active 
    ON users(cabinet_id, is_active) WHERE cabinet_id IS NOT NULL;

-- Index pour recherche rapide des accès utilisateur
CREATE INDEX IF NOT EXISTS idx_user_company_access_compound 
    ON user_company_access(user_id, company_id, access_level);

-- ============================================
-- CONTRAINTES DE COHÉRENCE
-- ============================================

-- Contrainte : En MODE CABINET, companies DOIT avoir un cabinet_id
-- (On ne peut pas l'ajouter en SQL car elle est conditionnelle au mode)
-- Cette contrainte sera vérifiée dans le code Java

-- Contrainte : Un user ne peut pas être lié à company_id ET cabinet_id simultanément
ALTER TABLE users ADD CONSTRAINT chk_user_tenant_mode 
    CHECK (
        (company_id IS NOT NULL AND cabinet_id IS NULL) OR  -- MODE SHARED/DEDICATED
        (company_id IS NULL AND cabinet_id IS NOT NULL) OR  -- MODE CABINET
        (company_id IS NULL AND cabinet_id IS NULL)         -- Utilisateur non encore assigné
    );

COMMENT ON CONSTRAINT chk_user_tenant_mode ON users IS 
    'Garantit qu''un user est soit en MODE SHARED/DEDICATED (company_id), soit en MODE CABINET (cabinet_id)';

-- ============================================
-- FIN DE MIGRATION
-- ============================================

-- Log de succès
DO $$
BEGIN
    RAISE NOTICE '✅ Migration V4 terminée avec succès';
    RAISE NOTICE '📊 Mode détecté : %', get_current_tenant_mode();
    RAISE NOTICE '🏢 Cabinets créés : %', (SELECT COUNT(*) FROM cabinets);
    RAISE NOTICE '🏭 Entreprises totales : %', (SELECT COUNT(*) FROM companies);
    RAISE NOTICE '👥 Utilisateurs totaux : %', (SELECT COUNT(*) FROM users);
END $$;